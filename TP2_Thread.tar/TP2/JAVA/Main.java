// Main.java
import java.util.concurrent.Semaphore;


public class Main {
	
	public static void main(String[] args) {
		Semaphore sem1, sem2;
                Thread1 thread1;
                Thread2 thread2;
		String message;
                
                /* création et initialisation des sémaphores */
                /* initialisation du message */
                /* création des thread1 et thread2 */
                /* démarrage des thread1 et thread2 */
                /* attente de la fin des threads */
		
		System.out.printf("%s", MonThread.getMessage());		
	}
	
}
