#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "parse.h"

char** Parse(char* command, int* bg)
{
  static char* argv[MAX];
  int i = 0;
  char* c;
  int longueur;
  
  longueur = strlen(command);
  if (command[longueur-2]=='&')
    {
      *bg = 1;
      command[longueur-2]=' ';
      command[longueur-1]='\0';
    }
  else 
    *bg = 0;

  while (*command != '\0' && isspace(*command)) {
    ++command;
  }
  if (*command == '\0') {
    return NULL;
  }
  for (;;) {
    if (i < MAX) {
      argv[i++] = command;
    } else {
      break;
    }
    while (*command != '\0' && !isspace(*command)) {
      ++command;
    }
    if (*command == '\0') {
      break;
    } else {
      *command++ = '\0';
    }
    while (*command != '\0' && isspace(*command)) {
      ++command;
    }
  }
  argv[i-1] = NULL;
  return argv;
}

