#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* On pourrait se debrouiller autrement  */
/* mais il est plus pratique de declarer */
/* les sémaphores en variables globales  */

sem_t *sem1, *sem2;

void* run1(void *arg) {
    /* variables locales à run1 */
    int i;
    char* message = (char*)arg;
    char* Min[26] = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};    

    for (i=0; i<13 ; i++) {
      /* utilisation d'un des sémaphores */
      sem_wait(sem2);
      /* section critique */
      strcat(message,Min[2*i]);
      /* utilisation d'un d'un des sémaphores */
      sem_post(sem1);
    }
    return NULL;
}

void* run2(void *arg) {
    /* variables locales à run2 */
    int i;
	char* message = (char*)arg;
	char* Maj[26] ={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    
    for (i=0; i<13 ; i++) {
      /* utilisation d'un des sémaphores */
      sem_wait(sem1);		
      /* section critique */
      strcat(message,Maj[2*i+1]);
      /* utilisation d'un d'un des sémaphores */
      sem_post(sem2);
    }
    return NULL;
}


int main() {

    char message[27];    // déclaration de la chaîne message 
    pthread_t th1, th2;  // déclaration des deux threads
    message[0]='\0';     // mise à zéro de la chaîne message
    
    /* ouverture et initialisation des deux sémaphores */
	sem1 = sem_open("/sem1",O_CREAT,600,0);
	sem2 = sem_open("/sem2",O_CREAT,600,1);
    /* création et exécution des deux threads */
	pthread_create(&th1,NULL,run1,(void*)message);
	pthread_create(&th2,NULL,run2,(void*)message);
    /* attente par le processus principal de la fin des deux threads */
    pthread_join(th1,NULL);
    pthread_join(th2,NULL);
    /* fermeture des deux sémaphores */
    sem_close(sem1);
    sem_close(sem2);
    
    /* destruction des deux sémaphores */
    sem_unlink("/sem1");
    sem_unlink("/sem2");
    printf("%s\n",message);    // affichage du message
  
    return 0;
}
