// MonThread.java
import java.util.concurrent.Semaphore;
public class MonThread extends Thread {
	protected Semaphore sem1, sem2;
	protected char caract; 
	protected static String message = "";
	protected static int compteur = 0;

        public static String getMessage(){
          return message;
        }

}
