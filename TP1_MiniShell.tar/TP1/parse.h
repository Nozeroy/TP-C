// longueur maximale de la ligne de commande
#define LENGTH 1024
// longueur maximale de chaque mot
#define MAXLMOT 256
// nombre max de mots
#define MAX 10


char** Parse(char* command, int* bg);

