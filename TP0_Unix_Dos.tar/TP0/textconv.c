// Programme écrit par JALAIN Enzo et DUPRAT Bastien



#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>


// Fonction pour convertir un fichier Unix en DOS
int unix2dos(const char* nomunix, const char* nomdos) {
    int fdUnix;
    FILE *fdDos;
    char caractere;

    // Ouvrir le fichier Unix en lecture seule
    fdUnix = open(nomunix, O_RDONLY);
    if (fdUnix == -1) {
        fprintf(stderr, "Erreur d'ouverture du fichier Unix\n");
        return -1;
    }

    // Ouvrir le fichier DOS en écriture
    fdDos = fopen(nomdos, "w");
    if (fdDos == NULL) {
        fprintf(stderr, "Erreur d'ouverture du fichier DOS\n");
        close(fdUnix);
        return -1;
    }

    // Lire le fichier Unix et écrire dans le fichier DOS
	while (read(fdUnix, &caractere, 1) != 0) {
		if (caractere != '\n') {
		    fprintf(fdDos, "%c", caractere);
		} else {
		    fprintf(fdDos, "\r\n");
		}
	}


    // Fermer les fichiers
    close(fdUnix);
    fclose(fdDos);

    return 0;
}

// Fonction pour convertir un fichier DOS en Unix
int dos2unix(const char* nomdos, const char* nomunix) {
    int fdDos;
    FILE *fdUnix;
    char caractere;

    // Ouvrir le fichier DOS en lecture seule
    fdDos = open(nomdos, O_RDONLY);
    if (fdDos == -1) {
        fprintf(stderr, "Erreur d'ouverture du fichier DOS\n");
        return -1;
    }

    // Ouvrir le fichier Unix en écriture
    fdUnix = fopen(nomunix, "w");
    if (fdUnix == NULL) {
        fprintf(stderr, "Erreur d'ouverture du fichier Unix\n");
        close(fdDos);
        return -1;
    }

    // Lire le fichier DOS et écrire dans le fichier Unix
	while (read(fdDos, &caractere, 1) != 0) {
		if (caractere != '\r') {
		    fprintf(fdUnix, "%c", caractere);
		}
	}

    // Fermer les fichiers
    close(fdDos);
    fclose(fdUnix);

    return 0;
}

int main(int argc, char *argv[]) {
    // Vérifier que le nombre correct d'arguments est fourni
	if (argc != 4 || strcmp(argv[1], "-help") == 0) {
        fprintf(stderr, "Usage: %s [-u2d|-d2u] <fichier source> <fichier destination>\n", argv[0]);
        return 1;
    }

    // Vérifier quelle conversion a été demandée
    if (strcmp(argv[1], "-u2d") == 0) {
        // Appel de la fonction de conversion Unix vers DOS
        if (unix2dos(argv[2], argv[3]) == 0) {
            printf("Conversion de Unix vers DOS réussie\n");
        } else {
            fprintf(stderr, "Erreur lors de la conversion Unix vers DOS\n");
            return 1;
        }
    } else if (strcmp(argv[1], "-d2u") == 0) {
        // Appel de la fonction de conversion DOS vers Unix
        if (dos2unix(argv[2], argv[3]) == 0) {
            printf("Conversion de DOS vers Unix réussie\n");
        } else {
            fprintf(stderr, "Erreur lors de la conversion DOS vers Unix\n");
            return 1;
        }
    } else {
        // Message d'erreur si le premier argument n'est pas reconnu
        fprintf(stderr, "Argument invalide. Utilisez '-u2d' ou '-d2u'.\n");
        return 1;
    }

    return 0;
}






