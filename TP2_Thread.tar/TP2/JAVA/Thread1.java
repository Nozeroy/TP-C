// Thread1.java
import java.util.concurrent.Semaphore;
public class Thread1 extends MonThread {		
	public Thread1(Semaphore sem1, Semaphore sem2) {
		this.caract = 'a';
		this.sem1 = sem1;
		this.sem2 = sem2;
	}
	
	public void run() {
          /* variables locales à run() */
          for (int i=0; i<13 ; i++) {
            /* utilisation d'un des semaphores */
            /* section critique */
            /* utilisation d'un des semaphores */
          }	    	    
	}	
}
