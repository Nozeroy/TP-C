// Main.java
import java.util.concurrent.Semaphore;


public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		Semaphore sem1, sem2;
        Thread1 thread1;
        Thread2 thread2;

        /* création et initialisation des sémaphores */
        sem1 = new Semaphore(0);
        sem2 = new Semaphore(1);
        
        thread1 = new Thread1(sem1,sem2);
        thread2 = new Thread2(sem1,sem2);
        
        /* création des thread1 et thread2 */ 		
        thread1.start();
        thread2.start();
        
        /* démarrage des thread1 et thread2 */
        
        thread1.join();
        thread2.join();
        
        /* attente de la fin des threads */
        		
        //sem1.close();
        //sem2.close();
            		
	
		System.out.printf("%s", MonThread.getMessage());		
	}
	
}
