#include <assert.h> 
#include <stdio.h> 
#include <stdlib.h>
#include <signal.h> 
#include <string.h>
#include <unistd.h> 
#include <errno.h> 
#include <fcntl.h> 
#include <sys/types.h>
#include <sys/wait.h> 
#include <sys/stat.h>
#include "parse.h"


int main() {
    char line[LENGTH];
    char** Argv;
    int pid, bg, longueur;

    printf("monshell> ");

    while (fflush(stdout) == 0 && fgets(line, LENGTH, stdin) != NULL) {
        longueur = strlen(line);
        
        if (longueur > 1) {
            // La fonction Parse() d�coupe la ligne line en mots
            Argv = Parse(line, &bg);
            
            // Traitement des arguments plac�s dans le tableau Argv[]
            if (Argv == NULL) {
                fprintf(stderr, "Erreur lors de l'analyse de la commande.\n");
                continue;
            }

            if (strcmp(Argv[0], "cd") == 0) {
                if (Argv[1] != NULL) {
                    if (chdir(Argv[1]) != 0) {
                    }
                } else {
                    chdir("/home");
                }
            } else if (strcmp(Argv[0], "exit") == 0) {
            	if (Argv[1] == NULL){
            		exit(0);
            	}
            	else{
            		int exit_status = atoi(Argv[1]); // permet de convertir un argument en entier
                	exit(exit_status);
                }
            } else {
                pid = fork();
                
                if (pid < 0) {
                } else if (pid == 0) {
                    execvp(Argv[0], Argv);
                    exit(EXIT_FAILURE); // Quitter le fils en cas d'erreur
                } else {
                    if (bg == 0) {
                        waitpid(pid, NULL, 0);
                    }
                }
            }
            
        }  // fin du : if (longueur > 1)  
        
        fflush(stdout);
        printf("monshell>");     	
    }

    return 0;
}

